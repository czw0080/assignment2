package com.example.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText text_1_1;
    private EditText text_1_2;
    private EditText text_2_1;
    private EditText text_2_2;
    private EditText text_3_1;
    private EditText text_3_2;
    private EditText text_4_1;
    private EditText text_4_2;

    private boolean change_flag = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text_1_1 = (EditText) findViewById(R.id.text1_1);
        text_1_2 = (EditText) findViewById(R.id.text1_2);
        text_2_1 = (EditText) findViewById(R.id.text2_1);
        text_2_2 = (EditText) findViewById(R.id.text2_2);
        text_3_1 = (EditText) findViewById(R.id.text3_1);
        text_3_2 = (EditText) findViewById(R.id.text3_2);
        text_4_1 = (EditText) findViewById(R.id.text4_1);
        text_4_2 = (EditText) findViewById(R.id.text4_2);

        text_1_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_1_1.getText().toString());
                        text_1_2.setText(String.valueOf((input - 32) / 1.8));
                    }
                } catch (Exception e) {
                    text_1_2.setText("");
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_1_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_1_2.getText().toString());
                        text_1_1.setText(String.valueOf(input * 1.8 + 32));
                    }
                } catch (Exception e) {
                    text_1_1.setText("");
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_2_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_2_1.getText().toString());
                        text_2_2.setText(String.valueOf(input * 0.62137));
                    }
                } catch (Exception e) {
                    text_2_2.setText("");
                    System.out.println(e);
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_2_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_2_2.getText().toString());
                        text_2_1.setText(String.valueOf(input * 1.60934));
                    }
                } catch (Exception e) {
                    text_2_1.setText("");
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_3_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_3_1.getText().toString());
                        text_3_2.setText(String.valueOf(input * 2.2046));
                    }
                } catch (Exception e) {
                    text_3_2.setText("");
                    System.out.println(e);
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_3_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_3_2.getText().toString());
                        text_3_1.setText(String.valueOf(input * 0.4536));
                    }
                } catch (Exception e) {
                    text_3_1.setText("");
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_4_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_4_1.getText().toString());
                        text_4_2.setText(String.valueOf(input * 0.2641721));
                    }
                } catch (Exception e) {
                    text_4_2.setText("");
                    System.out.println(e);
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

        text_4_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                try {
                    if (change_flag) {
                        change_flag = false;
                        double input = Double.parseDouble(text_4_2.getText().toString());
                        text_4_1.setText(String.valueOf(input * 3.78533));
                    }
                } catch (Exception e) {
                    text_4_1.setText("");
                }
                change_flag = true;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

        });

    }

}
